package atividade;

import br.edu.sumare.pergunta10.Pergunta10;
import br.edu.sumare.pergunta8.Pergunta8;


public class Atividade {

    public static void main(String[] args) {
       System.out.println("Execute cada uma das classes");
        
    }

}
